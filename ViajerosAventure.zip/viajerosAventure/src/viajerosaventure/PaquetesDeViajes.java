/*
Introducción a la programación
Universidad Fidélitas
Proyecto: Viajeros Aventure
Integrantes: Cristopher Navarro Guevara
             Yarón Hernández Chavarría
             Luis Carlos Gonzalez Ortega
 */
package viajerosaventure;

import javax.swing.JOptionPane;

public class PaquetesDeViajes {
    
    public void viajes(){
    
    JOptionPane.showMessageDialog(null,"-Viajeros Aventure-\n"
            + "-Esta opción se encuentra en mantenimientos-");
    
    
    }
    
    
    
}
